# CSC3600
Course Project

Requires -
XAMPP
Runs on Windows 10

php.ini file to be configured to include-
extension=pdo_sqlite
extension=sqlite3