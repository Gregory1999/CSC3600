<?php
	unlink("../site.db");
	header('Location: ../get_images.php');
?>